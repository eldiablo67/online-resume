package prethyud_rejil;

import java.util.Scanner;

public abstract class Room {
	protected String riddle;
	protected String answer;
	
	public Room(String riddle, String answer) {
		this.riddle = riddle;
		this.answer = answer;
	}
	
	public boolean play() {
		Scanner s = new Scanner(System.in);
		System.out.println(this.riddle);
		String userInput = s.nextLine();
		
		if(userInput.equalsIgnoreCase(this.answer)) {
			System.out.println("Congratulations! You have solved the puzzle and entered room: "+this.answer);
			return true;
		}
		else {
            System.out.println("Sorry, your answer is incorrect. Please try again.");
            return false;
	    }
	}
}
