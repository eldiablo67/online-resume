package prethyud_rejil;

public class KitchenRoom extends Room{

	public KitchenRoom() {
		super(
            "I'm the room where scents and flavors entice, And culinary magic is created with spice. Where am I?",
            "kitchen"
        );

}
