package prethyud_rejil;

public class LivingRoom extends Room{

	public LivingRoom() {
		super(
            "I'm the room where we gather and unwind, And in cozy comfort, sweet memories we find.Where am I?",
            "living room"
        );

}
