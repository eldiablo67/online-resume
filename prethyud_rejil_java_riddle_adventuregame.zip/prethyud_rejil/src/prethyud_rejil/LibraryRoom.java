package prethyud_rejil;

public class LibraryRoom extends Room{

	public LibraryRoom() {
		super(
            "I'm filled with tonnes and tonnes of history, A place where ancient wisdom is no mystery.Where am I?",
            "library"
        );

}
