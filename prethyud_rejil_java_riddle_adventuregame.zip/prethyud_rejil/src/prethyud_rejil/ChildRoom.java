package prethyud_rejil;

public class ChildRoom extends Room{

	public ChildRoom() {
		super("I'm the room where toys and playthings reign, And where imagination is never in vain.Where am I?", "child bedroom");
	}

}
