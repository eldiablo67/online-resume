package prethyud_rejil;

public class AdultRoom extends Room{

	public AdultRoom() {
		super("In me, you'll find intimate spaces that are private, And a place to retreat from the world and revive it. Where am I?", "adult bedroom");
	}

}
